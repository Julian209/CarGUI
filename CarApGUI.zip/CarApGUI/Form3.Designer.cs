﻿namespace CarApGUI
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.Wheels = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Colour = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Upholstery = new System.Windows.Forms.Label();
            this.Front = new System.Windows.Forms.PictureBox();
            this.Side = new System.Windows.Forms.PictureBox();
            this.Back = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Backk = new System.Windows.Forms.PictureBox();
            this.Interior = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Next = new System.Windows.Forms.PictureBox();
            this.Tire1 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Tire2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.BlackColor = new System.Windows.Forms.PictureBox();
            this.RedColor = new System.Windows.Forms.PictureBox();
            this.BlueColor = new System.Windows.Forms.PictureBox();
            this.WhiteColor = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.BlackUpholstery = new System.Windows.Forms.PictureBox();
            this.MochaUpholstery = new System.Windows.Forms.PictureBox();
            this.WhiteUpholstery = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Side)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Backk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Interior)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Next)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tire1)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Tire2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.flowLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BlackColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RedColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlueColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteColor)).BeginInit();
            this.flowLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BlackUpholstery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MochaUpholstery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteUpholstery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // Wheels
            // 
            this.Wheels.AutoSize = true;
            this.Wheels.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Wheels.ForeColor = System.Drawing.Color.Snow;
            this.Wheels.Location = new System.Drawing.Point(481, 384);
            this.Wheels.Name = "Wheels";
            this.Wheels.Size = new System.Drawing.Size(68, 20);
            this.Wheels.TabIndex = 2;
            this.Wheels.Text = "Wheels";
            this.Wheels.Click += new System.EventHandler(this.Vehicles_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox3.Location = new System.Drawing.Point(613, 407);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(117, 10);
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // Colour
            // 
            this.Colour.AutoSize = true;
            this.Colour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Colour.ForeColor = System.Drawing.Color.Snow;
            this.Colour.Location = new System.Drawing.Point(640, 384);
            this.Colour.Name = "Colour";
            this.Colour.Size = new System.Drawing.Size(61, 20);
            this.Colour.TabIndex = 4;
            this.Colour.Text = "Colour";
            this.Colour.Click += new System.EventHandler(this.Showroom_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureBox2.Location = new System.Drawing.Point(457, 407);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(117, 10);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox4.Location = new System.Drawing.Point(771, 407);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(117, 10);
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // Upholstery
            // 
            this.Upholstery.AutoSize = true;
            this.Upholstery.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Upholstery.ForeColor = System.Drawing.Color.Snow;
            this.Upholstery.Location = new System.Drawing.Point(780, 384);
            this.Upholstery.Name = "Upholstery";
            this.Upholstery.Size = new System.Drawing.Size(95, 20);
            this.Upholstery.TabIndex = 8;
            this.Upholstery.Text = "Upholstery";
            this.Upholstery.Click += new System.EventHandler(this.Products_Click);
            // 
            // Front
            // 
            this.Front.BackColor = System.Drawing.Color.DimGray;
            this.Front.Image = ((System.Drawing.Image)(resources.GetObject("Front.Image")));
            this.Front.ImageLocation = "";
            this.Front.Location = new System.Drawing.Point(384, 106);
            this.Front.Name = "Front";
            this.Front.Size = new System.Drawing.Size(460, 254);
            this.Front.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Front.TabIndex = 10;
            this.Front.TabStop = false;
            // 
            // Side
            // 
            this.Side.BackColor = System.Drawing.Color.DimGray;
            this.Side.Image = ((System.Drawing.Image)(resources.GetObject("Side.Image")));
            this.Side.Location = new System.Drawing.Point(850, 105);
            this.Side.Name = "Side";
            this.Side.Size = new System.Drawing.Size(152, 74);
            this.Side.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Side.TabIndex = 11;
            this.Side.TabStop = false;
            // 
            // Back
            // 
            this.Back.Image = ((System.Drawing.Image)(resources.GetObject("Back.Image")));
            this.Back.Location = new System.Drawing.Point(326, 209);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(43, 61);
            this.Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Back.TabIndex = 14;
            this.Back.TabStop = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dataGridView1.Location = new System.Drawing.Point(1008, 596);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(246, 191);
            this.dataGridView1.TabIndex = 16;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            // 
            // Backk
            // 
            this.Backk.BackColor = System.Drawing.Color.DimGray;
            this.Backk.Image = ((System.Drawing.Image)(resources.GetObject("Backk.Image")));
            this.Backk.Location = new System.Drawing.Point(850, 196);
            this.Backk.Name = "Backk";
            this.Backk.Size = new System.Drawing.Size(152, 74);
            this.Backk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Backk.TabIndex = 17;
            this.Backk.TabStop = false;
            // 
            // Interior
            // 
            this.Interior.BackColor = System.Drawing.Color.DimGray;
            this.Interior.Image = ((System.Drawing.Image)(resources.GetObject("Interior.Image")));
            this.Interior.Location = new System.Drawing.Point(850, 288);
            this.Interior.Name = "Interior";
            this.Interior.Size = new System.Drawing.Size(152, 72);
            this.Interior.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Interior.TabIndex = 18;
            this.Interior.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Snow;
            this.label1.Location = new System.Drawing.Point(482, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(440, 33);
            this.label1.TabIndex = 19;
            this.label1.Text = "START BUILDING YOUR CAR";
            // 
            // Next
            // 
            this.Next.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Next.Image = ((System.Drawing.Image)(resources.GetObject("Next.Image")));
            this.Next.Location = new System.Drawing.Point(1023, 209);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(41, 61);
            this.Next.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Next.TabIndex = 15;
            this.Next.TabStop = false;
            // 
            // Tire1
            // 
            this.Tire1.BackColor = System.Drawing.Color.Transparent;
            this.Tire1.Image = ((System.Drawing.Image)(resources.GetObject("Tire1.Image")));
            this.Tire1.Location = new System.Drawing.Point(3, 3);
            this.Tire1.Name = "Tire1";
            this.Tire1.Size = new System.Drawing.Size(104, 101);
            this.Tire1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Tire1.TabIndex = 23;
            this.Tire1.TabStop = false;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.Tire1);
            this.flowLayoutPanel1.Controls.Add(this.Tire2);
            this.flowLayoutPanel1.Controls.Add(this.pictureBox1);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(383, 423);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(619, 108);
            this.flowLayoutPanel1.TabIndex = 28;
            // 
            // Tire2
            // 
            this.Tire2.BackColor = System.Drawing.Color.Transparent;
            this.Tire2.Image = ((System.Drawing.Image)(resources.GetObject("Tire2.Image")));
            this.Tire2.Location = new System.Drawing.Point(113, 3);
            this.Tire2.Name = "Tire2";
            this.Tire2.Size = new System.Drawing.Size(104, 101);
            this.Tire2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Tire2.TabIndex = 24;
            this.Tire2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(223, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(104, 101);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.BlackColor);
            this.flowLayoutPanel2.Controls.Add(this.RedColor);
            this.flowLayoutPanel2.Controls.Add(this.BlueColor);
            this.flowLayoutPanel2.Controls.Add(this.WhiteColor);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(383, 533);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(619, 108);
            this.flowLayoutPanel2.TabIndex = 29;
            this.flowLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel2_Paint);
            // 
            // BlackColor
            // 
            this.BlackColor.BackColor = System.Drawing.Color.Transparent;
            this.BlackColor.Image = ((System.Drawing.Image)(resources.GetObject("BlackColor.Image")));
            this.BlackColor.Location = new System.Drawing.Point(3, 3);
            this.BlackColor.Name = "BlackColor";
            this.BlackColor.Size = new System.Drawing.Size(104, 101);
            this.BlackColor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BlackColor.TabIndex = 23;
            this.BlackColor.TabStop = false;
            // 
            // RedColor
            // 
            this.RedColor.BackColor = System.Drawing.Color.Transparent;
            this.RedColor.Image = ((System.Drawing.Image)(resources.GetObject("RedColor.Image")));
            this.RedColor.Location = new System.Drawing.Point(113, 3);
            this.RedColor.Name = "RedColor";
            this.RedColor.Size = new System.Drawing.Size(104, 101);
            this.RedColor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.RedColor.TabIndex = 24;
            this.RedColor.TabStop = false;
            // 
            // BlueColor
            // 
            this.BlueColor.BackColor = System.Drawing.Color.Transparent;
            this.BlueColor.Image = ((System.Drawing.Image)(resources.GetObject("BlueColor.Image")));
            this.BlueColor.Location = new System.Drawing.Point(223, 3);
            this.BlueColor.Name = "BlueColor";
            this.BlueColor.Size = new System.Drawing.Size(104, 101);
            this.BlueColor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BlueColor.TabIndex = 25;
            this.BlueColor.TabStop = false;
            // 
            // WhiteColor
            // 
            this.WhiteColor.BackColor = System.Drawing.Color.Transparent;
            this.WhiteColor.Image = ((System.Drawing.Image)(resources.GetObject("WhiteColor.Image")));
            this.WhiteColor.Location = new System.Drawing.Point(333, 3);
            this.WhiteColor.Name = "WhiteColor";
            this.WhiteColor.Size = new System.Drawing.Size(104, 101);
            this.WhiteColor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.WhiteColor.TabIndex = 26;
            this.WhiteColor.TabStop = false;
            this.WhiteColor.Visible = false;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.BlackUpholstery);
            this.flowLayoutPanel3.Controls.Add(this.MochaUpholstery);
            this.flowLayoutPanel3.Controls.Add(this.WhiteUpholstery);
            this.flowLayoutPanel3.Location = new System.Drawing.Point(383, 643);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(619, 108);
            this.flowLayoutPanel3.TabIndex = 30;
            // 
            // BlackUpholstery
            // 
            this.BlackUpholstery.BackColor = System.Drawing.Color.Transparent;
            this.BlackUpholstery.Image = ((System.Drawing.Image)(resources.GetObject("BlackUpholstery.Image")));
            this.BlackUpholstery.Location = new System.Drawing.Point(3, 3);
            this.BlackUpholstery.Name = "BlackUpholstery";
            this.BlackUpholstery.Size = new System.Drawing.Size(104, 101);
            this.BlackUpholstery.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BlackUpholstery.TabIndex = 23;
            this.BlackUpholstery.TabStop = false;
            // 
            // MochaUpholstery
            // 
            this.MochaUpholstery.BackColor = System.Drawing.Color.Transparent;
            this.MochaUpholstery.Image = ((System.Drawing.Image)(resources.GetObject("MochaUpholstery.Image")));
            this.MochaUpholstery.Location = new System.Drawing.Point(113, 3);
            this.MochaUpholstery.Name = "MochaUpholstery";
            this.MochaUpholstery.Size = new System.Drawing.Size(104, 101);
            this.MochaUpholstery.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.MochaUpholstery.TabIndex = 24;
            this.MochaUpholstery.TabStop = false;
            // 
            // WhiteUpholstery
            // 
            this.WhiteUpholstery.BackColor = System.Drawing.Color.Transparent;
            this.WhiteUpholstery.Image = ((System.Drawing.Image)(resources.GetObject("WhiteUpholstery.Image")));
            this.WhiteUpholstery.Location = new System.Drawing.Point(223, 3);
            this.WhiteUpholstery.Name = "WhiteUpholstery";
            this.WhiteUpholstery.Size = new System.Drawing.Size(104, 101);
            this.WhiteUpholstery.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.WhiteUpholstery.TabIndex = 25;
            this.WhiteUpholstery.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Snow;
            this.label2.Location = new System.Drawing.Point(41, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 33);
            this.label2.TabIndex = 31;
            this.label2.Text = "Car Name";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox5.Location = new System.Drawing.Point(47, 183);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(253, 10);
            this.pictureBox5.TabIndex = 32;
            this.pictureBox5.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Snow;
            this.label3.Location = new System.Drawing.Point(43, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 20);
            this.label3.TabIndex = 33;
            this.label3.Text = "Car Description";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1134, 771);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.flowLayoutPanel3);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Interior);
            this.Controls.Add(this.Backk);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.Side);
            this.Controls.Add(this.Front);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.Upholstery);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.Colour);
            this.Controls.Add(this.Wheels);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Side)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Backk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Interior)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Next)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tire1)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Tire2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.flowLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BlackColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RedColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BlueColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteColor)).EndInit();
            this.flowLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BlackUpholstery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MochaUpholstery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WhiteUpholstery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Wheels;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label Colour;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label Upholstery;
        private System.Windows.Forms.PictureBox Front;
        private System.Windows.Forms.PictureBox Side;
        private System.Windows.Forms.PictureBox Back;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewImageColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.PictureBox Backk;
        private System.Windows.Forms.PictureBox Interior;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Next;
        private System.Windows.Forms.PictureBox Tire1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.PictureBox Tire2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.PictureBox BlackColor;
        private System.Windows.Forms.PictureBox RedColor;
        private System.Windows.Forms.PictureBox BlueColor;
        private System.Windows.Forms.PictureBox WhiteColor;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.PictureBox BlackUpholstery;
        private System.Windows.Forms.PictureBox MochaUpholstery;
        private System.Windows.Forms.PictureBox WhiteUpholstery;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label3;
    }
}